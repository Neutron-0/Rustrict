```text
  ██████╗  ██╗   ██╗ ███████╗ ████████╗ ██████╗  ██╗  ██████╗ ████████╗
  ██╔══██╗ ██║   ██║ ██╔════╝ ╚══██╔══╝ ██╔══██╗ ██║ ██╔════╝ ╚══██╔══╝
  ██████╔╝ ██║   ██║ ███████╗    ██║    ██████╔╝ ██║ ██║         ██║   
  ██╔══██╗ ██║   ██║ ╚════██║    ██║    ██╔══██╗ ██║ ██║         ██║   
  ██║  ██║ ╚██████╔╝ ███████║    ██║    ██║  ██║ ██║ ╚██████╗    ██║   
  ╚═╝  ╚═╝  ╚═════╝  ╚══════╝    ╚═╝    ╚═╝  ╚═╝ ╚═╝  ╚═════╝    ╚═╝   
          Windows Network Bandwidth Limiter & Controller
```

# Rustrict

> **High-performance Windows network bandwidth limiter, traffic shaper, and device manager — written in native Rust.**

Rustrict employs asynchronous Layer 2 ARP operations, multi-protocol identity resolution, kernel-level packet filtering (WinDivert + Npcap), and router UPnP/TR-064 gateway interrogation to discover, fingerprint, monitor, and regulate every device on a local network — all from a single Windows CLI.

---

## Table of Contents

- [Architecture Overview](#architecture-overview)
- [System Architecture Diagram](#system-architecture-diagram)
- [Module Dependency Graph](#module-dependency-graph)
- [Core Subsystems](#core-subsystems)
  - [1. Platform & Kernel Interface Layer](#1-platform--kernel-interface-layer)
  - [2. Scanner Subsystem](#2-scanner-subsystem)
  - [3. Identity & Resolution Subsystem](#3-identity--resolution-subsystem)
  - [4. Router Gateway Discovery (UPnP / TR-064)](#4-router-gateway-discovery-upnp--tr-064)
  - [5. MITM & Traffic Shaping Engine](#5-mitm--traffic-shaping-engine)
  - [6. State & Persistence Subsystem](#6-state--persistence-subsystem)
  - [7. Wireless Subsystem (802.11)](#7-wireless-subsystem-80211)
  - [8. Scope & Boundary Enforcement](#8-scope--boundary-enforcement)
  - [9. Active Probing & Protocol Auditing (Offensive Assessment)](#9-active-probing--protocol-auditing)
  - [10. Resilience Simulation & Fault Injection](#10-resilience-simulation--fault-injection)
  - [11. Structured Assessment & Evidence Reporting](#11-structured-assessment--evidence-reporting)
- [End-to-End Data Flow](#end-to-end-data-flow)
  - [Device Discovery Pipeline](#device-discovery-pipeline)
  - [Traffic Throttling & MITM Pipeline](#traffic-throttling--mitm-pipeline)
  - [Persistent Block Lifecycle](#persistent-block-lifecycle)
- [CLI Command Reference](#cli-command-reference)
- [Requirements](#requirements)
- [Installation](#installation)
- [Building from Source](#building-from-source)
- [Project Structure](#project-structure)
- [Test Suite](#test-suite)
- [External Dependencies](#external-dependencies)

---

## Architecture Overview

Rustrict is organized into modular architectural layers, each responsible for a distinct concern in the network management and security assessment pipeline:

| Layer | Modules | Responsibility |
| :--- | :--- | :--- |
| **CLI & Presentation** | `src/cli/`, `src/main.rs` | Interactive REPL shell, ANSI-colored device tables, target resolution, argument parsing |
| **Platform & Kernel Interface** | `src/platform/`, `build.rs` | Windows API bindings (`SendARP`, `IsUserAnAdmin`), PowerShell automation, WinDivert/Npcap dynamic linking |
| **Scanner** | `src/scanner/` | Parallel ARP subnet sweeping via Rayon, rate-limited in batches of 48 to prevent router queue exhaustion |
| **Identity & Resolution** | `src/resolver/`, `src/gateway/` | 10-protocol hostname fingerprinting chain, OUI vendor lookup, router UPnP/TR-064 SOAP interrogation |
| **MITM & Traffic Shaping** | `src/spoofer/`, `src/limiter/`, `src/monitor/` | Bidirectional ARP cache poisoning, WinDivert kernel packet interception, token-bucket rate limiting |
| **Scope & Boundaries** | `src/core/scope.rs` | Operational CIDR boundary validation, IP/MAC exclusions, and strict mode authorization enforcement |
| **Offensive Assessment Probes** | `src/probes/` | Multi-port TCP enumeration, banner grabbing, TLS posture (SSLv3/TLS1.0/1.1), SMB signing & SMBv1 auditing |
| **Resilience & Fault Simulation** | `src/limiter/fault.rs` | Configurable packet drop percentage, latency delay, and jitter simulation via WinDivert |
| **Evidence & Reporting** | `src/cli/export.rs` | Structured Markdown executive summaries, JSON asset inventory, and SARIF v2.1.0 compliance outputs |
| **State & Persistence** | `src/state.rs` | JSON-backed durable block rules surviving restarts and rescans |
| **Wireless (802.11)** | `src/wireless/` | Deauth frame crafting, Radiotap parsing, 4-way WPA handshake / PMKID inspection |

---


## System Architecture Diagram

```mermaid
flowchart TD
    subgraph USER["User Terminal (Administrator PowerShell)"]
        CLI["rustrict.exe"]
    end

    subgraph PRESENTATION["CLI & Presentation Layer"]
        Banner["Banner (ASCII Art)"]
        REPL["Interactive REPL Loop"]
        Table["Host Inventory Table (comfy-table)"]
        TargetRes["Target Resolver (ID / IP / all)"]
    end

    subgraph PLATFORM["Platform & Kernel Interface"]
        WinAPI["Windows APIs (SendARP, IsUserAnAdmin)"]
        PSCmd["PowerShell Commands (Get-NetRoute, Set-NetIPInterface)"]
        NpcapDLL["wpcap.dll (Npcap)"]
        WinDivertDLL["WinDivert.dll + WinDivert64.sys"]
    end

    subgraph DISCOVERY["Discovery & Identity Pipeline"]
        Scanner["SubnetScanner (Rayon Parallel ARP)"]
        Resolver["Multi-Protocol Identity Resolver"]
        Sniffer["Passive DHCP Sniffer (Background)"]
        Gateway["GatewayClient (UPnP / TR-064)"]
        OUI["OUI Vendor Database (25+ vendors)"]
    end

    subgraph MITM["Traffic Control & MITM Engine"]
        Spoofer["ArpSpoofer (Bidirectional Poisoning)"]
        L2Sender["RawL2Sender (pcap_sendpacket)"]
        Limiter["TrafficLimiter (WinDivert NETWORK_FORWARD)"]
        TokenBucket["TokenBucket Rate Shaper"]
        Meter["BandwidthMeter (Atomic Counters)"]
    end

    subgraph PERSIST["Persistence"]
        State["PersistentState (rustrict_state.json)"]
    end

    subgraph WIRELESS["802.11 Wireless Subsystem"]
        Deauth["Deauth Frame Crafter"]
        FrameParser["802.11 Frame Parser"]
        Handshake["WPA Handshake / PMKID Inspector"]
        Radiotap["Radiotap Header Parser"]
    end

    CLI --> Banner
    CLI --> REPL
    REPL --> Table
    REPL --> TargetRes
    REPL -->|scan| Scanner
    REPL -->|limit or block| Spoofer
    REPL -->|limit or block| Limiter
    REPL -->|block| State
    REPL -->|free| State

    Scanner -->|Parallel Probes| WinAPI
    Scanner -->|Background Query| Gateway
    Scanner -->|Discovered Hosts| Resolver
    Resolver --> OUI
    Sniffer -->|Passive Captures| REPL

    Spoofer -->|Crafted ARP Frames| L2Sender
    L2Sender --> NpcapDLL
    Limiter --> WinDivertDLL
    Limiter -->|Rate Check| TokenBucket
    Limiter -->|Traffic Stats| Meter

    Gateway -->|SSDP M-SEARCH| PSCmd
    WinAPI --> PSCmd

    State -->|Load on Startup| REPL
    State -->|Restore Blocks| Spoofer
    State -->|Restore Blocks| Limiter

    Deauth --> L2Sender
    FrameParser --> Handshake
    Radiotap --> FrameParser
```

---

## Module Dependency Graph

```mermaid
flowchart LR
    subgraph main_bin["Binary (src/main.rs)"]
        main["main()"]
    end

    subgraph lib_crate["Library Crate (src/lib.rs)"]
        cli_mod["cli"]
        gateway_mod["gateway"]
        limiter_mod["limiter"]
        monitor_mod["monitor"]
        platform_mod["platform"]
        resolver_mod["resolver"]
        scanner_mod["scanner"]
        spoofer_mod["spoofer"]
        state_mod["state"]
        types_mod["types"]
        wireless_mod["wireless"]
    end

    main -->|use rustrict::cli| cli_mod
    main -->|use rustrict::platform| platform_mod

    cli_mod --> scanner_mod
    cli_mod --> spoofer_mod
    cli_mod --> limiter_mod
    cli_mod --> resolver_mod
    cli_mod --> state_mod
    cli_mod --> types_mod
    cli_mod --> monitor_mod

    scanner_mod --> platform_mod
    scanner_mod --> resolver_mod
    scanner_mod --> gateway_mod
    scanner_mod --> types_mod

    resolver_mod --> gateway_mod
    resolver_mod --> types_mod

    spoofer_mod --> types_mod

    limiter_mod --> types_mod

    gateway_mod --> types_mod

    state_mod --> types_mod
```

---

## Core Subsystems

### 1. Platform & Kernel Interface Layer

The platform layer (`src/platform/`) provides the bridge between Rustrict and the Windows kernel. A compile-time guard rejects non-Windows targets:

```rust
#[cfg(not(windows))]
compile_error!("Rustrict is built specifically for Windows (Windows 10/11 x64).");
```

**Key operations performed through this layer:**

| Function | Mechanism | Purpose |
| :--- | :--- | :--- |
| `is_privileged()` | Win32 `IsUserAnAdmin()` | Verify Administrator elevation |
| `send_arp(ip)` | Win32 `SendARP` (iphlpapi.dll) | Synchronous kernel-level ARP resolution |
| `get_arp_cache()` | Parses `arp -a` output | Seed scanner with known devices |
| `get_default_interface()` | PowerShell `Get-NetRoute`, `Get-NetIPAddress`, `Get-NetAdapter` | Auto-detect active NIC, gateway IP/MAC, local IP/MAC, Npcap device path |
| `enable_ip_forwarding()` | PowerShell `Set-NetIPInterface -Forwarding Enabled` | Required for MITM packet forwarding |
| `disable_ip_forwarding()` | PowerShell `Set-NetIPInterface -Forwarding Disabled` | Clean shutdown restoration |

**The build system** (`build.rs`) automatically locates and bundles WinDivert binaries (`WinDivert.dll`, `WinDivert64.sys`) from Anaconda/pip `pydivert` site-packages or local directories into the target output folder.

---

### 2. Scanner Subsystem

The scanner (`src/scanner/arp.rs`) performs high-speed parallel ARP sweeps across IPv4 subnets:

```mermaid
sequenceDiagram
    participant User as "User (scan command)"
    participant CLI as "RustrictCli"
    participant Scanner as "SubnetScanner"
    participant GW as "GatewayClient (Background)"
    participant Rayon as "Rayon Thread Pool"
    participant Kernel as "Windows SendARP API"
    participant Resolver as "Identity Resolver"

    User->>CLI: scan (--fresh, --range)
    CLI->>Scanner: scan_subnet() / scan_range()

    par Background Router Query
        Scanner->>GW: refresh_hosts() [async thread]
        GW-->>Scanner: DHCP lease table cached
    and Parallel ARP Sweep
        Scanner->>Scanner: Compute subnet bounds (network..broadcast)
        Scanner->>Scanner: Seed from ARP cache (non-fresh mode)
        loop Batches of 48 IPs
            Scanner->>Rayon: par_iter() over IP batch
            Rayon->>Kernel: send_arp(ip) per IP
            Kernel-->>Rayon: MAC address or timeout
            Note over Rayon: 10ms throttle between batches
        end
    end

    Scanner->>Resolver: resolve_identity_with_gateway(ip, mac, gateway_client)
    Resolver-->>Scanner: HostIdentity (hostname, source, vendor)
    Scanner-->>CLI: Vec of Host
    CLI->>CLI: reconcile_hosts(new_hosts, is_fresh)
    CLI->>CLI: render_hosts_table()
```

**Key design decisions:**
- **Batch size of 48** with **10ms inter-batch delays** prevents consumer routers from dropping ARP frames due to queue exhaustion.
- **Non-fresh scans** pre-seed from the Windows kernel ARP cache (`arp -a`), reducing network traffic for already-known devices.
- **Fresh scans** (`--fresh`) purge all offline, unmanaged entries from the table while strictly preserving any host with active limits, blocks, or persistent rules.

---

### 3. Identity & Resolution Subsystem

Rustrict resolves device hostnames through a **10-protocol priority chain**, stopping at the first successful identification:

```mermaid
flowchart TD
    Start["Discovered IP + MAC"] --> GatewayCheck{"Is this the Gateway IP?"}
    GatewayCheck -->|Yes| GWLabel["Gateway (NameSource::Gateway)"]
    GatewayCheck -->|No| LocalCheck{"Is this the local machine?"}
    LocalCheck -->|Yes| LocalLabel["COMPUTERNAME (NameSource::Local)"]
    LocalCheck -->|No| UPnP["1. Router UPnP / TR-064 Lookup"]

    UPnP -->|Found| UPnPResult["DHCP Hostname (NameSource::RouterUpnp)"]
    UPnP -->|Not Found| SMB["2. SMB2 NTLMSSP Type 2 Challenge (TCP 445)"]

    SMB -->|Found| SMBResult["NetBIOS Name (NameSource::Smb)"]
    SMB -->|Not Found| TLS["3. TLS X.509 Certificate CN (TCP 3389, 443)"]

    TLS -->|Found| TLSResult["Certificate CN (NameSource::Tls)"]
    TLS -->|Not Found| NetBIOS["4. NetBIOS NBNS Query (UDP 137)"]

    NetBIOS -->|Found| NBResult["Workstation Name (NameSource::NetBios)"]
    NetBIOS -->|Not Found| mDNS["5. mDNS Reverse PTR (UDP 5353)"]

    mDNS -->|Found| mDNSResult[".local Hostname (NameSource::Mdns)"]
    mDNS -->|Not Found| LLMNR["6. LLMNR PTR Query (UDP 5355)"]

    LLMNR -->|Found| LLMNRResult["Link-Local Name (NameSource::Llmnr)"]
    LLMNR -->|Not Found| HTTP["7. HTTP Banner/Title (TCP 80, 8080)"]

    HTTP -->|Found| HTTPResult["Page Title (NameSource::HttpTitle)"]
    HTTP -->|Not Found| RDNS["8. Reverse DNS (Native WinSock)"]

    RDNS -->|Found| RDNSResult["PTR Record (NameSource::Dns)"]
    RDNS -->|Not Found| OUI["9. OUI Vendor-Only Identification"]

    OUI --> Unresolved["NameSource::Unresolved (vendor still resolved)"]

    classDef resolved fill:#2d5016,stroke:#4ade80,color:#fff;
    class UPnP,SMB,TLS,NetBIOS,mDNS,LLMNR,HTTP,RDNS resolved;
```

**Additionally**, a **passive background sniffer** (`PassiveIdentitySniffer`) runs continuously in a separate thread, capturing broadcast DHCP packets via Npcap promiscuous mode and extracting **DHCP Option 12 (Host Name)** from BOOTP/DHCP exchanges. These passively discovered identities are merged into the host table on every `hosts` command.

**OUI Vendor Database** covers 25+ manufacturers including Apple, Samsung, Xiaomi, Google, Amazon, Intel, Realtek, TP-Link, Cisco, Dell, HP, Lenovo, and more. Randomized MACs (locally administered bit set) are detected and flagged.

---

### 4. Router Gateway Discovery (UPnP / TR-064)

The gateway module (`src/gateway/`) queries the local router's UPnP `LANHostConfigManagement:1` service to extract the authoritative DHCP lease table — providing device names that are impossible to obtain by probing endpoints directly (e.g., firewalled smartphones, IoT devices, smart TVs).

```mermaid
sequenceDiagram
    participant Scanner as "SubnetScanner"
    participant GW as "GatewayClient"
    participant SSDP as "SsdpScanner"
    participant Router as "Router (192.168.x.1)"
    participant SOAP as "SoapClient"

    Scanner->>GW: refresh_hosts() [background thread]

    Note over GW, SSDP: Phase 1: Service Discovery
    GW->>SSDP: discover(gateway_ip)

    alt Multicast Discovery
        SSDP->>Router: M-SEARCH to 239.255.255.250:1900
        Note right of SSDP: Target: InternetGatewayDevice:1
        Router-->>SSDP: HTTP 200 (LOCATION header)
    else Unicast Fallback (Wi-Fi isolation)
        loop Unicast Ports 1900, 49152, 49153, 5000, 80, 8080
            SSDP->>Router: HTTP GET /rootDesc.xml
            SSDP->>Router: HTTP GET /desc.xml
            SSDP->>Router: HTTP GET /igd.xml
            SSDP->>Router: HTTP GET /upnp/IGD.xml
            SSDP->>Router: HTTP GET /gatedesc.xml
        end
        Router-->>SSDP: XML Description Document
    end

    SSDP->>SSDP: Parse XML for controlURL and serviceType
    SSDP-->>GW: GatewayServiceInfo (addr, control_url, service_urn)

    Note over GW, SOAP: Phase 2: DHCP Lease Enumeration
    loop Index 0 to N until Error 714
        GW->>SOAP: get_generic_host_entry(index)
        SOAP->>Router: SOAP POST (GetGenericHostEntry)
        alt Valid Entry
            Router-->>SOAP: XML Response (IP, MAC, HostName, InterfaceType, Active)
            SOAP-->>GW: GatewayHostEntry
        else Error 714 (NoSuchEntryInArray)
            Router-->>SOAP: SOAP Fault 714
            Note over SOAP: Enumeration complete
        end
    end

    GW->>GW: Cache entries by IP in Arc of RwLock of HashMap
    GW-->>Scanner: Cached, ready for instant lookups
```

---

### 5. MITM & Traffic Shaping Engine

The traffic control system operates through three tightly coordinated subsystems:

```mermaid
flowchart TD
    subgraph ARP_POISONING["ARP Poisoning Engine (src/spoofer/)"]
        SpooferEngine["ArpSpoofer Engine"]
        WorkerThread["Background Worker Thread (2s interval)"]
        L2Sender["RawL2Sender (wpcap.dll)"]

        SpooferEngine -->|add host| WorkerThread
        WorkerThread -->|Every 2s: Blocked Host| PoisonBlackhole["Poison Target & Gateway to BLACKHOLE_MAC"]
        WorkerThread -->|Every 2s: Limited Host| PoisonLocal["Poison Target & Gateway to Local NIC MAC"]
        PoisonBlackhole --> L2Sender
        PoisonLocal --> L2Sender
    end

    subgraph HARDWARE_DROP["L2 Network Fabric (Switch / AP)"]
        L2Sender -->|Blackholed Frame| SwitchDrop["Switch / Router Drops Packet in Hardware (0% Host Load)"]
    end

    subgraph PACKET_FILTER["Kernel Packet Interception (src/limiter/)"]
        WinDivert["WinDivert (NETWORK_FORWARD)"]
        IPParse["IPv4 Header Parser (src/dst IP)"]
        RuleCheck{"Active Rule?"}
        ULBucket["Upload TokenBucket"]
        DLBucket["Download TokenBucket"]
        DivertDrop["DROP Packet"]
        Forward["FORWARD Packet (WinDivertSend)"]

        WinDivert -->|Intercepted Packet| IPParse
        IPParse --> RuleCheck
        RuleCheck -->|Limited: Outbound| ULBucket
        RuleCheck -->|Limited: Inbound| DLBucket
        ULBucket -->|Tokens Available| Forward
        ULBucket -->|Tokens Exhausted| DivertDrop
        DLBucket -->|Tokens Available| Forward
        DLBucket -->|Tokens Exhausted| DivertDrop
        RuleCheck -->|No Rule| Forward
    end

    subgraph MONITORING["Traffic Monitoring (src/monitor/)"]
        Meter["BandwidthMeter"]
        AtomicCounters["Per-Host Atomic Counters (bytes_sent, bytes_recv)"]
        Meter --> AtomicCounters
    end

    L2Sender -->|MITM Traffic Redirected| WinDivert
    Forward --> Meter
```

#### Token Bucket Rate Limiter

The `TokenBucket` implements a classic token-bucket algorithm with high-resolution timing:

```
Capacity (burst) = rate_bps * 2 (default)
Refill rate      = rate_bps bits/second
Consumption      = packet_size_bytes * 8 bits per packet

For each intercepted packet:
  1. elapsed = now - last_refill
  2. tokens += elapsed * rate_bps (capped at capacity)
  3. if tokens >= packet_bits: consume → FORWARD
  4. else: DROP (throttle)
```

#### ARP Restoration on Cleanup

When a device is freed (`free` command) or Rustrict exits (`quit`/`exit`), the spoofer sends **3 bursts** of legitimate ARP replies to both the target and gateway, restoring the authentic MAC-to-IP bindings and undoing the cache poisoning.

---

### 6. State & Persistence Subsystem

```mermaid
flowchart TD
    subgraph STARTUP["Application Launch & Re-Arming"]
        Start(["rustrict.exe Launched"]) --> CheckState{"rustrict_state.json exists?"}
        CheckState -->|Yes| LoadState["PersistentState::load()"]
        CheckState -->|No| Ready["Interactive REPL Shell Ready"]

        LoadState --> ParseBlocked["Parse Persisted Block Rules & Scope"]
        ParseBlocked --> RestoreSpoof["ArpSpoofer::add() - Resume Blackhole Poisoning"]
        ParseBlocked --> RestoreDrop["TrafficLimiter::block() - Re-install Drop Filter"]
        RestoreSpoof --> Ready
        RestoreDrop --> Ready
    end

    subgraph RUNTIME["Interactive Runtime State"]
        Ready --> WaitCmd["rustrict prompt: Waiting for Command"]

        WaitCmd -->|block target| ExecBlock["Add Host to PersistentState"]
        ExecBlock --> WriteSave1["Write to ProgramData rustrict_state.json"]
        WriteSave1 --> EngageBlock["Engage L2 Blackhole & WinDivert Drop"]
        EngageBlock --> WaitCmd

        WaitCmd -->|free target| ExecFree["Remove Host from PersistentState"]
        ExecFree --> WriteSave2["Update rustrict_state.json"]
        WriteSave2 --> RestoreTarget["Send Authentic ARP Burst & Remove Drop"]
        RestoreTarget --> WaitCmd

        WaitCmd -->|scan fresh| Sweep["Subnet Sweep"]
        Sweep --> Reconcile["reconcile_hosts()"]
        Reconcile --> PreserveRule["Purge stale entries but PRESERVE all blocked hosts"]
        PreserveRule --> WaitCmd
    end

    subgraph SHUTDOWN["Clean Termination"]
        WaitCmd -->|quit or exit| StopEngine["Stop Spoofer & Limiter"]
        StopEngine --> Unpoison["Send 3-Burst Authentic ARP Replies"]
        Unpoison --> DisableFwd["Disable Windows IP Forwarding"]
        DisableFwd --> Exit(["Process Exited (Rules Preserved on Disk)"])
    end
```

**Persistence format** (`%ProgramData%\Rustrict\rustrict_state.json` or `%USERPROFILE%\rustrict_state.json`):
```json
{
  "blocked_hosts": [
    {
      "ip": "192.168.18.50",
      "mac": "a4:83:e7:21:00:19",
      "name": "Lakshyas-iPhone",
      "direction": "Both"
    }
  ]
}
```

**Critical invariant:** During `scan --fresh`, the reconciliation algorithm **never** prunes hosts that have `persistent_block = true` or an active `HostStatus::Blocked` / `HostStatus::Limited` status — even if they are offline and absent from the fresh scan results.

---

### 7. Wireless Subsystem (802.11)

The wireless module provides low-level 802.11 frame analysis capabilities:

```mermaid
flowchart LR
    subgraph CAPTURE["Raw Wireless Capture"]
        RawFrame["Raw 802.11 Frame (bytes)"]
    end

    subgraph PARSING["Frame Parsing Pipeline"]
        Radiotap["RadiotapHeader::parse()"]
        Dot11["Dot11Frame::parse()"]
        TypeCheck{"Frame Type?"}
    end

    subgraph MANAGEMENT["Management Frame Analysis"]
        Beacon["Beacon: extract_ssid()"]
        Probe["Probe: extract_ssid()"]
        DeauthRx["Deauth Detection"]
    end

    subgraph DATA_FRAME["Data Frame Analysis"]
        EAPOLCheck{"is_eapol_frame()?"}
        HandshakeInspect["inspect_eapol_key()"]
        MsgIdentify{"Message Number?"}
        Msg1["Message 1: ANonce + PMKID extraction"]
        Msg2["Message 2: SNonce"]
        Msg3["Message 3: GTK Install"]
        Msg4["Message 4: Confirmation"]
    end

    subgraph INJECTION["Frame Injection"]
        CraftDeauth["craft_deauth_frame()"]
        BiDeauth["craft_bidirectional_deauth()"]
        Inject["RawL2Sender::send_frame()"]
    end

    RawFrame --> Radiotap
    Radiotap -->|Payload after header| Dot11
    Dot11 --> TypeCheck

    TypeCheck -->|Management| Beacon
    TypeCheck -->|Management| Probe
    TypeCheck -->|Management| DeauthRx
    TypeCheck -->|Data| EAPOLCheck

    EAPOLCheck -->|Yes| HandshakeInspect
    HandshakeInspect --> MsgIdentify
    MsgIdentify --> Msg1
    MsgIdentify --> Msg2
    MsgIdentify --> Msg3
    MsgIdentify --> Msg4

    CraftDeauth --> Inject
    BiDeauth --> CraftDeauth
```

**Capabilities:**
- **Deauthentication frame crafting:** Generates valid IEEE 802.11 management frames (Frame Control `0x00c0`) with configurable reason codes. Bidirectional mode sends both AP→Client (Reason 7: Class 3 frame from nonassociated STA) and Client→AP (Reason 3: STA leaving) frames.
- **Radiotap header parsing:** Zero-copy extraction of channel frequency (MHz) and signal strength (dBm) from monitor-mode captures.
- **802.11 frame parsing:** Decodes Frame Control, addresses (Receiver, Transmitter, BSSID), To/From DS bits, and management subtypes (Beacon, Probe, Auth, Deauth, Disassociation).
- **WPA/WPA2 handshake inspection:** Identifies all four EAPOL-Key messages in the 4-way handshake by analyzing key info flags (`Pairwise`, `Install`, `ACK`, `MIC`). Extracts **PMKID** from RSN KDE tag (`00-0F-AC-04`) in Message 1.

---

### 8. Scope & Boundary Enforcement

The Scope subsystem (`src/core/scope.rs`) acts as a safeguard preventing unauthorized operations during assessment, traffic shaping, or fault simulation:

```mermaid
flowchart TD
    Target["Target Action Requested (limit, block, ports, audit, simulate)"] --> CheckExcludedIP{"IP in excluded_ips?"}
    CheckExcludedIP -->|Yes| RejectIP["Reject: Target IP explicitly excluded"]
    CheckExcludedIP -->|No| CheckExcludedMAC{"MAC in excluded_macs?"}
    CheckExcludedMAC -->|Yes| RejectMAC["Reject: Target MAC explicitly excluded"]
    CheckExcludedMAC -->|No| CheckStrict{"Strict Mode Enabled?"}
    CheckStrict -->|No| AllowAction["Allow Action"]
    CheckStrict -->|Yes| CheckCIDR{"Matches allowed_cidrs?"}
    CheckCIDR -->|Yes| AllowAction
    CheckCIDR -->|No| RejectScope["Reject: Out of authorized scope CIDR"]
```

**Capabilities:**
- **CIDR Range Normalization:** Automatically computes network boundaries from prefix notation (`192.168.1.50/24` $\rightarrow$ `192.168.1.0/24`).
- **Explicit Exclusions:** Supports excluding specific critical endpoints by IPv4 or MAC address (e.g. gateway router, management server, monitoring probes).
- **Strict Authorization Mode:** When enabled, any operation targeting an endpoint outside configured CIDRs is rejected immediately with a descriptive error.

---

### 9. Active Probing & Protocol Auditing

The Probes subsystem (`src/probes/`) shifts Rustrict from passive visibility into active posture assessment:

```mermaid
flowchart LR
    TargetHost["Target Host"] --> PortScan["Port Scanner (Top 25 + Custom Ranges)"]
    PortScan --> Banners["Banner Grabbing (HTTP HEAD, Service Greetings)"]
    
    TargetHost --> TLSAudit["TLS Posture Auditor"]
    TLSAudit --> SSLv3["SSL 3.0 / TLS 1.0 / TLS 1.1 ClientHello Handshakes"]
    TLSAudit --> Ciphers["Weak Cipher Probe (RC4, 3DES, NULL)"]
    
    TargetHost --> SMBAudit["SMB Configuration Auditor"]
    SMBAudit --> SMB1["SMBv1 Dialect Probe"]
    SMBAudit --> SMBSign["SMB2/3 Negotiate Signing Requirement Check"]
```

**Capabilities:**
- **High-Speed Multi-Threaded Port Scanner:** Rayon-parallel TCP connect probing with non-blocking socket timeouts (400ms read/write). Covers 25 curated infrastructure ports or arbitrary user ranges (`parse_ports_arg`).
- **Banner Grabbing & Service Identification:** Fast HTTP `Server:` header extraction and greeting banner capture for SSH, FTP, SMTP, and POP3.
- **TLS Protocol & Cipher Posture Audit:** Probes servers with crafted `ClientHello` messages to detect support for cryptographically deprecated SSL 3.0, TLS 1.0, and TLS 1.1, and flags weak ciphers.
- **SMB Signing & Protocol Audit:** Inspects SMB2/SMB3 Negotiate responses to verify whether message signing is mandatory or optional (identifying NTLM relay vulnerabilities), and detects legacy SMBv1 support.

---

### 10. Resilience Simulation & Fault Injection

The Resilience engine (`src/limiter/fault.rs`, `src/limiter/divert.rs`) injects real-world network degradations into live traffic intercepted via WinDivert:

```mermaid
sequenceDiagram
    participant App as "Target Device Traffic"
    participant WD as "WinDivert Driver (Forward Layer)"
    participant Fault as "FaultProfile Engine"
    participant Queue as "Async Delayed Worker Queue"
    participant Wire as "Network Interface"

    App->>WD: Packet Forwarded
    WD->>Fault: Evaluate Host Fault Profile
    alt Packet is dropped (Simulated Loss)
        Fault-->>WD: Drop Packet
    else Packet is delayed
        Fault->>Queue: Enqueue DelayedPacket (delay_ms +/- jitter_ms)
        Note over Queue: Non-blocking background worker delay
        Queue->>Wire: Forward packet after timer expires
    else Normal Forward
        Fault->>Wire: WinDivertSend packet immediately
    end
```

**Capabilities:**
- **Packet Loss Simulation:** Configurable drop probability (0% to 100%) using nanosecond entropy.
- **Latency & Jitter Simulation:** Adds configurable base delay (in ms) combined with uniform random jitter variance.
- **Dynamic Attachment:** Applied and cleared on live target devices without restarting the application (`simulate <id> drop 20 delay 100 jitter 20` and `simulate <id> clear`).

---

### 11. Structured Assessment & Evidence Reporting

The Export subsystem (`src/cli/export.rs`) generates structured assessment artifacts:

- **Executive Markdown Report (`.md`):** Formatted summary containing operational scope boundaries, executive risk breakdown, open service inventory, and prioritized vulnerability findings with actionable remediation advice.
- **JSON Asset Inventory (`.json`):** Machine-readable asset and finding inventory for programmatic ingestion.
- **SARIF v2.1.0 Compliance (`.sarif`):** Standard Static Analysis Results Format compatible with GitHub Code Scanning, VS Code SARIF Viewer, and CI/CD security quality gates.

---


## End-to-End Data Flow

### Device Discovery Pipeline

```mermaid
flowchart TD
    A["User: scan --fresh"] --> B["RustrictCli::handle_scan()"]
    B --> C["Parse --fresh and --range flags"]
    C --> D["SubnetScanner::scan_subnet()"]

    D --> E["Compute network/broadcast bounds from netmask"]
    E --> F{"Fresh mode?"}

    F -->|No| G["Seed discovered set from Windows ARP cache"]
    F -->|Yes| H["Start with empty set"]

    G --> I["Spawn background thread: GatewayClient::refresh_hosts()"]
    H --> I

    I --> J["SSDP M-SEARCH + Unicast Probe to SOAP GetGenericHostEntry"]
    J --> K["Cache router DHCP lease table"]

    I --> L["Rayon parallel ARP sweep (batches of 48, 10ms throttle)"]
    L --> M["platform::send_arp(ip) for each IP in subnet"]
    M --> N{"MAC returned?"}
    N -->|Yes| O["Add to discovered set"]
    N -->|No| P["Skip IP"]

    O --> Q["Parallel identity resolution (Rayon par_iter)"]
    Q --> R["resolve_identity_with_gateway()"]
    R --> S["10-protocol priority chain"]
    S --> T["Return Vec of Host with hostname, vendor, source"]

    T --> U["RustrictCli::reconcile_hosts()"]
    U --> V{"Fresh mode?"}
    V -->|Yes| W["Prune offline unmanaged hosts, preserve blocked/limited"]
    V -->|No| X["Merge: update existing, append new, preserve all"]

    W --> Y["Re-index IDs, sort by IP"]
    X --> Y
    Y --> Z["render_hosts_table() to Terminal output"]
```

### Traffic Throttling & MITM Pipeline

```mermaid
sequenceDiagram
    participant User as "User"
    participant CLI as "RustrictCli"
    participant Resolve as "Target Resolver"
    participant Spoofer as "ArpSpoofer"
    participant L2 as "RawL2Sender (Npcap)"
    participant Target as "Target Device"
    participant Gateway as "Network Gateway"
    participant Limiter as "TrafficLimiter"
    participant WD as "WinDivert Kernel Driver"
    participant TB as "TokenBucket"

    User->>CLI: limit 1 500kbit --download
    CLI->>Resolve: resolve_targets(1)
    Resolve-->>CLI: Host at 192.168.18.50

    Note over CLI: Phase 1: Establish MITM Position
    CLI->>Spoofer: add(host)
    loop Every 2 seconds
        Spoofer->>L2: craft_arp_reply(target, gateway is Local MAC)
        L2->>Target: Poisoned ARP Reply
        Spoofer->>L2: craft_arp_reply(gateway, target is Local MAC)
        L2->>Gateway: Poisoned ARP Reply
    end
    Note over Target, Gateway: All traffic now routes through local machine

    Note over CLI: Phase 2: Install Rate Limiter
    CLI->>Limiter: limit(ip, Incoming, 500kbit)
    Limiter->>Limiter: Create HostLimitRule with DL TokenBucket(500kbps)
    Limiter->>WD: WinDivertOpen(ip, NETWORK_FORWARD)

    Note over WD: Phase 3: Runtime Packet Processing
    loop Every forwarded packet
        WD->>Limiter: Intercepted IPv4 packet
        Limiter->>Limiter: Extract src/dst IP from IPv4 header
        alt Packet destined for 192.168.18.50 (download)
            Limiter->>TB: try_consume(packet_bits)
            alt Tokens available
                TB-->>Limiter: true
                Limiter->>WD: WinDivertSend (forward packet)
            else Tokens exhausted
                TB-->>Limiter: false
                Note over Limiter: Packet DROPPED (throttled)
            end
        else Unrelated packet
            Limiter->>WD: WinDivertSend (forward immediately)
        end
    end
```

### Persistent Block Lifecycle

```mermaid
flowchart TD
    A["User: block 1"] --> B["resolve_targets(1) to Host at 192.168.18.50"]
    B --> C["host.status = Blocked(Both)"]
    C --> D["host.persistent_block = true"]

    D --> E["PersistentState::add_blocked(host, Both)"]
    E --> F["Write ProgramData rustrict_state.json to disk"]

    D --> G["ArpSpoofer::add(host) - Start L2 Blackhole Poisoning"]
    D --> H["TrafficLimiter::block(ip, Both) - Drop Fallback"]

    F --> I["User closes Rustrict (quit)"]
    I --> J["ArpSpoofer::stop() - Restore ARP tables (3-burst)"]
    I --> K["TrafficLimiter::stop() - Close WinDivert handle"]
    I --> L["platform::disable_ip_forwarding()"]

    L --> M["User relaunches rustrict.exe"]
    M --> N["PersistentState::load() reads rustrict_state.json"]
    N --> O["For each blocked_host in state:"]
    O --> P["platform::send_arp(ip) to Resolve current MAC"]
    O --> Q["ArpSpoofer::add(host) - Resume Blackhole Poisoning"]
    O --> R["TrafficLimiter::block(ip, dir) - Resume Drop Filter"]

    Q --> S["Device is blocked again without user intervention"]
    R --> S

    S --> T["User: free 1"]
    T --> U["ArpSpoofer::remove(ip) - Restore authentic ARP"]
    T --> V["TrafficLimiter::unlimit(ip) - Remove WinDivert rule"]
    T --> W["PersistentState::remove_blocked(ip)"]
    W --> X["Write updated rustrict_state.json"]
    X --> Y["Block permanently removed"]
```

---

## CLI Command Reference

### Command-Line Arguments & Flags

Rustrict can be launched with options or run freestanding diagnostics without administrator privileges:

```powershell
rustrict [OPTIONS]
rustrict nic [COMMAND] [ARGS...]
```

| Flag | Argument | Description | Admin Required |
| :--- | :--- | :--- | :--- |
| **`-h, --help`** | None | Displays full usage guide and interactive shell reference | No |
| **`-v, --version`** | None | Prints version information and target architecture | No |
| **`-l, --list-interfaces`** | None | Lists all detected network adapters, IPs, MACs, link speeds, and statuses | No |
| **`-i, --interface`** | `<name\|index>` | Explicitly binds to the specified network adapter (e.g. `-i "Wi-Fi"` or `-i 17`) | Yes (if live) |
| **`--offline, --no-adapter`** | None | Decoupled offline session without probing or binding to physical NICs | No |
| **`--router-lab`** | None | Read-only router laboratory mode (zero active network probes or mutations) | No |
| **`--strict`** | None | Forces strict scope mode on startup (enforce explicit CIDR boundaries) | Yes (if live) |
| **`--permissive`** | None | Forces permissive scope mode on startup (permits all RFC 1918 private LANs) | Yes (if live) |
| **`--blockmode`** | `<blackhole\|mitm>` | Sets default block mode: `blackhole` (L2 drop) or `mitm` (WinDivert kernel drop) | Yes (if live) |

### Interactive Shell Commands

| Command | Syntax | Description |
| :--- | :--- | :--- |
| **`scan`** | `scan [--range <start-end>] [--fresh] [--ports]` | Discovers online hosts via parallel ARP sweep. `--fresh` purges stale offline entries while preserving active rules. `--range 100-200` limits scan to a specific host range within the subnet. `--ports` automatically triggers multi-port service enumeration on discovered hosts. |
| **`hosts`** | `hosts` (aliases: `devices`, `targets`, `list`, `ls`) | Displays the current device inventory table with IP, MAC, verified hostname, vendor, online/offline state, and management status (Free / Limited / Blocked). Merges any passively discovered DHCP identities. |
| **`status`** | `status` (alias: `state`) | Displays an overview of current operational state: active blocked and limited devices, strict or permissive scope mode, authorized CIDRs, exclusions, and active network interface. |
| **`scope`** | `scope [status \| add <cidr\|ip> \| add all \| remove <cidr> \| reset \| clear \| exclude-ip <ip> \| exclude-mac <mac> \| strict <on\|off> \| on \| off]` | Manages authorized target boundaries and operational rules of engagement. `scope add all` authorizes all private RFC 1918 subnets (`10.0.0.0/8`, `172.16.0.0/12`, `192.168.0.0/16`). `scope reset` returns to local interface defaults. When `strict` mode is enabled, actions targeting out-of-scope CIDRs or excluded IP/MAC endpoints are blocked automatically. |
| **`ports`** | `ports <targets> [port-range]` | Performs high-speed multi-threaded TCP connect scan with greeting and HTTP banner grabbing. Defaults to curated Top 25 management ports (`21`, `22`, `80`, `443`, `445`, `3389`, etc.) or custom lists/ranges (e.g. `80,443,8000-8080`). |
| **`audit`** | `audit <targets>` | Executes active security posture checks against target hosts: tests TLS version negotiation (flags obsolete SSLv3, TLS 1.0, TLS 1.1, weak ciphers) and SMB configuration (detects SMBv1 support and checks whether SMB message signing is mandatory vs optional). |
| **`simulate`** | `simulate <targets> [drop <0-100>] [delay <ms>] [jitter <ms>]` | Simulates network resilience conditions and fault injection on intercepted target traffic via WinDivert. Use `simulate <targets> clear` to restore normal forwarding. |
| **`export`** | `export [markdown\|json\|sarif] [filename]` | Generates structured security assessment and inventory evidence. Supports Markdown executive summaries, structured JSON asset/findings dumps, and industry-standard SARIF v2.1.0 reports for GitHub Security and CI/CD ingestion. |
| **`limit`** | `limit <targets> <rate> [--upload] [--download]` | Throttles device bandwidth. Targets can be device IDs (`1`), IP addresses (`192.168.18.50`), comma-separated lists (`1,192.168.18.50`), or `all`. Rate supports `bit`, `kbit`, `mbit`, `gbit` units. Direction defaults to `Both`. |
| **`block`** | `block <targets> [--upload] [--download]` | Completely cuts off device internet access by dropping all forwarded packets. **Persists across restarts** — blocked devices are saved to `rustrict_state.json` and automatically re-armed on next launch. |
| **`blockmode`** | `blockmode [blackhole \| mitm]` (alias: `spoofer`) | Toggles block enforcement mechanism. `blackhole` routes blocked targets to unicast blackhole MAC `02:bf:00:00:00:01` (dropped silently at L2 switch/AP with zero local CPU/NIC load). `mitm` routes traffic through local host and drops packets in the WinDivert kernel filter. |
| **`free`** | `free <targets>` (aliases: `unblock`, `unlimit`, `release`) | Removes all limits and blocks for specified devices. Restores authentic ARP cache entries. Removes persistent block rules from disk. |
| **`add`** | `add <ip> [--mac <mac>]` | Manually inserts a device into the management table. If `--mac` is omitted, the MAC is resolved via the Windows kernel ARP API. |
| **`nic`** | `nic [status\|health\|stats\|list] [name\|index]` | Physical network adapter health diagnostic. Performs bounded 2-second telemetry sampling, computes Rx/Tx throughput rates (bps), link speed utilization %, packet errors and discards, and heuristic health classifications (`Normal`, `Elevated`, `Saturated`, `Degraded`, `Unavailable`). Can also be invoked directly from the CLI without entering the interactive shell or requiring administrative privileges: `rustrict.exe nic list` or `rustrict.exe nic health "Wi-Fi"`. |
| **`clear`** | `clear` / `cls` | Clears the terminal screen. |
| **`help`** | `help` / `?` | Displays command reference. |
| **`exit`** | `quit` / `exit` | Stops all spoofing, restores ARP tables, disables IP forwarding, and exits cleanly. |


### Target Resolution Syntax

Targets support flexible mixed-format addressing:

```
rustrict > block 1                    # By device ID
rustrict > block 192.168.18.50        # By IPv4 address
rustrict > block 1,2,3                # Multiple IDs (comma-separated)
rustrict > block 40 61 84 93          # Multiple IDs (space-separated)
rustrict > block 1, 192.168.18.50, 3  # Mixed IDs and IPs
rustrict > block all                  # All discovered devices
rustrict > unblock 40 61 84 93        # Unblock multiple targets (alias for free)
rustrict > limit all 200kbit          # Throttle entire network
```

---

## Requirements

| Requirement | Details |
| :--- | :--- |
| **Operating System** | Windows 10 / 11 (x86_64) |
| **Privileges** | Administrator terminal (PowerShell or Command Prompt) |
| **Npcap** | [npcap.com](https://npcap.com/) — installed in **WinPcap API-compatible mode** |
| **WinDivert** | `WinDivert.dll` + `WinDivert64.sys` — auto-bundled by `build.rs` or manually placed alongside `rustrict.exe` |
| **Rust Toolchain** | `rustc` / `cargo` 1.75+ (for building from source) |

---

## Installation

### Quick Install (PowerShell)

Install Rustrict and kernel driver dependencies automatically in one command:

```powershell
irm https://raw.githubusercontent.com/Neutron-0/Rustrict/main/scripts/install.ps1 | iex
```

The installer:
1. Downloads the verified release package and validates its SHA-256 checksum against `SHA256SUMS.txt`.
2. Installs `rustrict.exe`, `WinDivert.dll`, and `WinDivert64.sys` to `%LOCALAPPDATA%\Programs\rustrict\bin`.
3. Adds Rustrict to your User `PATH` environment variable.

### Pre-compiled Releases
Standalone zip archives containing `rustrict.exe`, WinDivert drivers, and SHA-256 manifests are available on the [GitHub Releases](https://github.com/Neutron-0/Rustrict/releases) page.

---

## Building from Source

```powershell
# Clone the repository
git clone https://github.com/Neutron-0/rustrict.git
cd rustrict

# Build optimized release binary
cargo build --release

# Run the automated test suite (350 tests across 30 binaries)
cargo test

# Launch in Standard Mode (Administrator terminal required)
.\target\release\rustrict.exe

# Launch in Read-Only Router-Lab Mode (Standard user supported; zero startup gateway probes)
.\target\release\rustrict.exe --router-lab
```

The compiled binary is located at `target\release\rustrict.exe`. WinDivert drivers are automatically copied to the release directory by the build script.

---

## Project Structure

```
rustrict/
├── Cargo.toml                    # Package manifest (rustrict v2.0.2)
├── Cargo.lock                    # Dependency lockfile
├── build.rs                      # Build script: auto-bundles WinDivert binaries
├── .gitignore                    # Excludes target/, state file, IDE configs
├── README.md                     # This document
│
├── src/
│   ├── main.rs                   # Binary entry point: banner, elevation check, REPL launch
│   ├── lib.rs                    # Library root: exports all 11 modules
│   ├── types.rs                  # Core types: MacAddress, Host, BitRate, Direction, HostStatus, NameSource
│   │
│   ├── cli/
│   │   ├── mod.rs                # CLI module exports
│   │   ├── banner.rs             # ASCII art banner renderer
│   │   ├── export.rs             # Structured evidence export: Markdown, JSON, SARIF v2.1.0
│   │   ├── prompt.rs             # RustrictCli: REPL loop, command handlers, reconciliation logic
│   │   └── table.rs              # Table renderers for hosts, services, findings, and scope (comfy-table)
│   │
│   ├── core/
│   │   ├── mod.rs                # Core module exports
│   │   ├── scope.rs              # ScopeManager & Ipv4Cidr: boundary enforcement, CIDR normalization, exclusions
│   │   └── assessment.rs         # Assessment domain types: ServiceEntry, AuditFinding, AuditSeverity
│   │
│   ├── probes/
│   │   ├── mod.rs                # Probes module exports
│   │   ├── ports.rs              # Parallel TCP connect port scanner (Top 25 + custom ranges) & banner grabbing
│   │   ├── tls_audit.rs          # TLS posture auditor: crafts ClientHello for SSLv3/TLS1.0/1.1 and weak ciphers
│   │   └── smb_audit.rs          # SMB posture auditor: SMBv1 probe & SMB2/3 message signing validation
│   │
│   ├── platform/
│   │   ├── mod.rs                # Platform gate: compile_error for non-Windows
│   │   └── windows.rs            # Windows API bindings: SendARP, IsUserAnAdmin, PowerShell commands
│   │
│   ├── scanner/
│   │   ├── mod.rs                # Scanner module exports
│   │   └── arp.rs                # SubnetScanner: parallel ARP sweep, batch throttling, gateway integration
│   │
│   ├── resolver/
│   │   ├── mod.rs                # Identity resolver: 10-protocol priority chain, HTTP title probe
│   │   ├── passive.rs            # PassiveIdentitySniffer: background DHCP Option 12 capture
│   │   ├── oui.rs                # OUI vendor database (25+ manufacturers)
│   │   ├── smb.rs                # SMB2 NTLMSSP Type 2 challenge hostname extraction
│   │   ├── tls.rs                # TLS X.509 certificate Common Name parser
│   │   ├── netbios.rs            # NetBIOS NBNS Node Status Query (UDP 137)
│   │   ├── mdns.rs               # mDNS reverse PTR lookup (UDP 5353)
│   │   ├── llmnr.rs              # LLMNR PTR query (UDP 5355)
│   │   └── dns.rs                # Reverse DNS via nslookup
│   │
│   ├── gateway/
│   │   ├── mod.rs                # GatewayClient: caching coordinator
│   │   ├── ssdp.rs               # SSDP M-SEARCH + unicast HTTP probe for UPnP service discovery
│   │   ├── soap.rs               # SOAP request executor + XML tag extractor
│   │   └── hosts.rs              # GatewayHostEntry struct
│   │
│   ├── spoofer/
│   │   ├── mod.rs                # Spoofer module exports
│   │   ├── engine.rs             # ArpSpoofer: background poisoning worker, ARP restoration
│   │   └── raw_l2.rs             # RawL2Sender: Npcap pcap_sendpacket, ARP frame crafting
│   │
│   ├── limiter/
│   │   ├── mod.rs                # Limiter module exports
│   │   ├── divert.rs             # TrafficLimiter: WinDivert NETWORK_FORWARD packet filter & fault loop
│   │   ├── fault.rs              # FaultProfile: drop probability, latency delay, and jitter simulation
│   │   └── token_bucket.rs       # TokenBucket + SharedTokenBucket rate limiter
│   │
│   ├── monitor/
│   │   ├── mod.rs                # Monitor module exports
│   │   └── counter.rs            # BandwidthMeter: per-host atomic traffic counters
│   │
│   ├── wireless/
│   │   ├── mod.rs                # Wireless module exports
│   │   ├── deauth.rs             # 802.11 Deauthentication frame crafter
│   │   ├── frame.rs              # Dot11Frame parser, FrameType/ManagementSubtype enums
│   │   ├── handshake.rs          # WPA 4-way handshake inspector, PMKID extractor
│   │   └── radiotap.rs           # Radiotap header parser (channel freq, signal dBm)
│   │
│   └── state.rs                  # PersistentState: JSON serialization for durable block rules
│
└── tests/
    ├── unit_tests.rs             # MAC formatting, OUI lookup, BitRate parsing, TokenBucket, ARP crafting, Deauth, EAPOL
    ├── test_assessment.rs        # Offensive assessment: CIDR containment, ScopeManager strict rules, port parsing, SARIF/JSON/Markdown
    ├── test_fixes.rs             # Regression tests: BitRate overflow, mDNS echo, HTML title Unicode, SOAP prefixes, LLMNR, diagnostics
    ├── test_dhcp.rs              # DHCP Option 12 packet parsing
    ├── test_smb.rs               # SMB2 NTLMSSP Type 2 challenge parsing
    ├── test_tls.rs               # X.509 certificate CN extraction
    ├── test_gateway.rs           # SOAP XML parsing, SSDP header parsing, GatewayHostEntry construction
    └── test_target_resolution.rs # Target resolver: ID/IP/mixed/all, dedup, fresh rescan, persistence roundtrip
```

---

## Test Suite

Rustrict includes **350 automated tests** across 29 test binaries covering all critical subsystems:

| Test File | Tests | Coverage |
| :--- | :---: | :--- |
| `src/lib.rs` (unittests) | 46 | Bounded process execution and child process reaping, concurrent pipe draining, secret buffer zeroization, fail-closed persistent block restoration, observable forwarding cleanup with verification, baseline preservation, terminating error cmdlet handling, and robust NIC health telemetry (zero false-normal, monotonic decrease reset detection, missing counter invalidation, ambiguous matching) |
| `test_assessment.rs` | 5 | CIDR normalization, ScopeManager strict authorization and exclusions, port string parsing, FaultProfile jitter/drop simulation, SARIF v2.1.0/JSON/Markdown report generation |
| `test_avm_admin.rs` | 20 | AVM FRITZ!Box TR-064 SOAP admin, Digest auth, HostFilter WAN pause/resume, multi-target policies, and TLS certificate error rejection |
| `test_convenience_commands.rs` | 8 | Fast multi-target parsing (comma & space separated), scope add all, scope reset/clear, unblock/devices/status aliases, and dynamic spoofer status synchronization |
| `test_cli_confirmation.rs` | 10 | Operator mutation confirmation workflows, auto-confirm `--yes` flag, cancellation, and evidence validation |
| `test_dhcp.rs` | 1 | DHCP Option 12 (Host Name) extraction from raw BOOTP packet bytes |
| `test_diagnostics.rs` | 15 | Read-only diagnostic checks, evidence export schema, secret sanitization, offline evidence validation, and inventory normalization |
| `test_fixes.rs` | 8 | BitRate overflow protection, mDNS question echo parsing, HTML title Unicode extraction, SOAP tag prefix handling, bounded scan ranges, LLMNR PTR parsing, PersistentState bidirectional direction serialization, environment diagnostics |
| `test_gateway.rs` | 4 | SOAP XML tag extraction, missing tag handling, SSDP response header parsing, GatewayHostEntry construction |
| `test_mikrotik_admin.rs` | 20 | MikroTik RouterOS v7 REST admin, HTTPS enforcement, autonomous recovery watchdog, multi-target policies, and atomic rollback |
| `test_openwrt_admin.rs` | 21 | OpenWrt ubus JSON-RPC admin, session management, firewall4 NFT rules, autonomous recovery watchdog, and HTTP redirect rejection |
| `test_persistence.rs` | 9 | Cross-process file locking contention, atomic write replacement, schema versioning, secret zeroization on disk, and audit history logging |
| `test_policy_engine.rs` | 13 | Execution engine state transitions, gateway/controller lockout protection, conflict preflight detection, and Unicode-safe diagnostic redaction |
| `test_policy_views.rs` | 7 | Policy table formatting, lifecycle state transitions, detailed policy inspection, and failure sanitization |
| `test_protocol_integration.rs` | 17 | Local loopback router emulation, HTTP/REST/SOAP/SSH protocol flows, operation-aware retry isolation, and uncertain outcome handling |
| `test_provider_contracts.rs` | 6 | Provider contract compliance, normalized capabilities, read-only guarantees, and structured diagnostic export |
| `test_reliability.rs` | 9 | DPAPI credential protection, memory hygiene, multi-instance file lock synchronization, and corrupted state recovery |
| `test_router_admin.rs` | 12 | Router administration baseline, mock provider auth, timeout simulation, scope exclusion enforcement, and clean disconnect |
| `test_safe_networking.rs` | 12 | Hermetic scanner test seams (0 ARP probes), safe scoped IP forwarding lifecycle, structured forwarding cleanup reporting and retryability, fail-closed persistent restoration on forwarding failure, subnet network and directed-broadcast rejection, RFC 3021 /31 and /32 preservation, LinkSpeed parsing, NIC health metrics, fail-closed forwarding aborts, and standalone hermetic CLI dispatch |
| `test_smb.rs` | 2 | SMB2 NTLMSSP Type 2 challenge AV_PAIR parsing (MsvAvDnsComputerName / MsvAvNbComputerName) and odd-trailing-byte robustness |
| `test_ssh_admin.rs` | 17 | OpenWrt SSH provider, key auth, command injection prevention, non-root user rejection, and autonomous watchdog lifecycle |
| `test_target_resolution.rs` | 12 | Target resolution by ID, by IP, mixed lists, `all` keyword, deduplication, unknown ID/IP errors, ambiguous records, non-destructive upsert, fresh rescan pruning with blocked device preservation, PersistentState roundtrip |
| `test_tls.rs` | 2 | X.509 certificate Common Name extraction via ASN.1 OID `2.5.4.3` and BMPString odd-trailing-byte robustness |
| `test_unifi_admin.rs` | 19 | Ubiquiti UniFi Controller HTTPS REST admin, session cookie auth, Traffic Rules / Firewall Rules, site discovery, and cleanup |
| `test_unified_admin.rs` | 10 | Unified RouterRegistry provider dispatch, no silent fallback to ARP spoofing, lockout prevention, and preflight validation |
| `test_verification.rs` | 5 | Blackhole MAC properties (unicast, locally administered), TokenBucket rate shaping/refill, ScopeManager strict mode, RFC 3021 /31 and /32 subnet clamping |
| `unit_tests.rs` | 7 | MAC formatting/parsing, OUI vendor lookup, BitRate unit parsing, TokenBucket rate-limiting, Layer 2 ARP reply frame crafting, 802.11 Deauth frame generation, EAPOL frame detection |
| `test_batched_readiness.rs` | 6 | Centralized target admission contract (mandatory controller/gateway exclusions, concrete boundary enforcement), untrusted saved scope sanitization, fail-closed without packet injection driver, multi-target atomic rollback, and read-only router-lab mode |
| `test_router_lab_isolation.rs` | 16 | Strict router-lab allowlist enforcement, default-deny rejection of destructive/mutating commands, privilege decoupling (standard user support), clean EOF shutdown, fake/mock provider safety, and source counter proof of 0 side effects |
| `test_router_lab_zero_probe.rs` | 10 | Zero-probe router-lab startup, passive local OS route/IP/adapter resolution, unresolved gateway MAC handling, zero SendARP/ICMP pings, enforcement-driver loading bypass, and clean shutdown |
| **Total** | **350** | **100% Passing automated test suite on Windows 11 MSVC and Rust 1.88.0 MSRV** |

Run the full suite:
```powershell
cargo test
```


---

## External Dependencies

| Dependency | Type | Purpose |
| :--- | :--- | :--- |
| **WinDivert** (`WinDivert.dll`, `WinDivert64.sys`) | Kernel driver + DLL | Intercepts IPv4 packets at the `NETWORK_FORWARD` layer for bandwidth throttling and packet dropping. Dynamically loaded at runtime. |
| **Npcap** (`wpcap.dll`) | User-mode DLL | Raw Layer 2 Ethernet frame transmission (`pcap_sendpacket`) for ARP spoofing, promiscuous packet capture (`pcap_open_live` / `pcap_next_ex`) for passive DHCP snooping. |
| **Windows iphlpapi.dll** | System DLL | Native `SendARP` API for synchronous kernel-level ARP resolution during subnet scanning. |
| **PowerShell** | System utility | Network interface discovery (`Get-NetRoute`, `Get-NetIPAddress`, `Get-NetAdapter`) and IP forwarding management (`Set-NetIPInterface`). |

---

## License

Rustrict is released under a proprietary source-available license. See the [LICENSE](LICENSE) file for complete terms and conditions.

Under this license, you are welcome to view, inspect, clone, compile, and run the software locally for personal, educational, research, and non-commercial evaluation purposes. Commercial exploitation, redistribution, embedding, and bundling into proprietary products or services are prohibited without prior written authorization.

Docs: [Install](docs/INSTALL.md) · [Usage](docs/USAGE.md) · [Safety](docs/SAFETY.md) · [Security](SECURITY.md) · [Contributing](CONTRIBUTING.md) · [Changelog](CHANGELOG.md).
